import { AfterViewInit,Component, OnInit } from '@angular/core';
import Map from 'ol/Map';
import View from 'ol/View';
import TileLayer from 'ol/layer/Tile';
import OSM from 'ol/source/OSM';
import TileWMS from 'ol/source/TileWMS.js';
import * as $ from "jquery";
import Chart from 'chart.js/auto';
import  {transform}  from 'ol/proj';

import Overlay from 'ol/Overlay.js';
import XYZ from 'ol/source/XYZ.js';
import {toLonLat} from 'ol/proj.js';
import {toStringHDMS} from 'ol/coordinate.js';

declare var url:any;
  

interface URLInter{
  fid: String;
  OBJECTID: Number;
  GIS_Plot_S: String;
  PlotNotxt: String;
  ZoneName: String;
  GIS_Area_m: Number;
  CategoryNa: String;
  SubCategor: String;
  EstateOffi: String;
}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})


export class AppComponent implements OnInit,AfterViewInit {

  
  data: URLInter[] = this.url;

  public wmsSource = new TileWMS({
    url: 'https://ahocevar.com/geoserver/wms',
    params: {'LAYERS': 'ne:ne', 'TILED': true},
    serverType: 'geoserver',
    crossOrigin: 'anonymous',
  });
  
  public wmsLayer = new TileLayer({
    source: this.wmsSource
  });

  public view = new View({
    center:transform([77.2965,28.3654],"EPSG:4326","EPSG:3857"),
    // center: [77.2965,28.3654],
    zoom: 13,
  });

  map: Map = new Map;

  dtOptions: DataTables.Settings = {};
  public chart: any;



  ReadMore:boolean = true
  visible:boolean = false
  but1:boolean = false
  but2:boolean = false
  but3:boolean = false

  public show:boolean = false;
  public buttonName:any = 'Show';

  public wmsSourceHSVPPlotParcel = new TileWMS({
    url: 'http://190.168.51.85:8085/geoserver/HSVP/wms',
    params: {'LAYERS': 'HSVP:Plot_Parcel', 'TILED': false},
    serverType: 'geoserver',
    crossOrigin: 'anonymous',
  });

  public wmsLayerHSVPPlotParcel = new TileLayer({
    source: this.wmsSourceHSVPPlotParcel
  });

  public wmsSourceHSVPBuildings = new TileWMS({
    url: 'http://190.168.51.85:8085/geoserver/HSVP/wms',
    params: {'LAYERS': 'HSVP:Buidings', 'TILED': false},
    serverType: 'geoserver',
    crossOrigin: 'anonymous',
  });
    
    
  public wmsLayerHSVPBuilding = new TileLayer({
    source: this.wmsSourceHSVPBuildings
  });
    
    
  public wmsSourceHSVPRoad = new TileWMS({
    url: 'http://190.168.51.85:8085/geoserver/HSVP/wms',
    params: {'LAYERS': 'HSVP:Roads', 'TILED': false},
    serverType: 'geoserver',
    crossOrigin: 'anonymous',
  });
      
      
  public wmsLayerHSVPRoad = new TileLayer({
    source: this.wmsSourceHSVPRoad
  });

  options = [
    1,
    2,
    3
  ]

  ngAfterViewInit(): void {} 

  ngOnInit(): void {
    this.createChart();
    this.dtOptions = {
      paging: false,
      scrollY: 150,
      scrollX: true
    };
    
    this.map = new Map({
      layers: [this.wmsLayer],
      target: 'map',
      view: this.view,
    });
  


    //map.addLayer(this.wmsLayerHSVPPlotParcel);
              
    /* Elements that make up the popup.*/
    const container = document.getElementById('popup');
    const content = document.getElementById('popup-content');
    const closer = document.getElementById('popup-closer');

    this.map.on('singleclick',  (evt) => {
      (<HTMLInputElement>document.getElementById('info')).innerHTML = '';
      const data = this.wmsLayerHSVPPlotParcel.getData(evt.pixel);
      const viewResolution = this.view.getResolution() as number;

      console.log(viewResolution);
      this.url = this.wmsSourceHSVPPlotParcel.getFeatureInfoUrl(
        evt.coordinate,
        viewResolution,
        'EPSG:3857',
        {'INFO_FORMAT': 'application/json'}
      ); /*
      if (url) {
        fetch(url)
        .then((response) => response.text())
        .then((html) => {
          (<HTMLInputElement>document.getElementById('info')).innerHTML = html;
        });
      }*/
    });
  }

  onChange(op:number) {
    if(op == 1){
      if((<HTMLInputElement>document.getElementById("option1")).checked){
        this.map.addLayer(this.wmsLayerHSVPPlotParcel);
        this.but1 = !this.but1;
      }
  
     else{
        this.but1 = !this.but1;
        this.map.removeLayer(this.wmsLayerHSVPPlotParcel);
      }
    }
    
    else if(op == 2){
      if((<HTMLInputElement>document.getElementById("option2")).checked){
        this.map.addLayer(this.wmsLayerHSVPBuilding);
        this.but2 = !this.but2;
      }
  
      else{
        this.map.removeLayer(this.wmsLayerHSVPBuilding);
        this.but2 = !this.but2;
      }
    }
    
    else if(op == 3){
      if((<HTMLInputElement>document.getElementById("option3")).checked){
        this.map.addLayer(this.wmsLayerHSVPRoad);
        this.but3 = !this.but3;
      }
  
      else{
        this.map.removeLayer(this.wmsLayerHSVPRoad);
        this.but3 = !this.but3;
      }
    }
  }
    
  

  onclick($target: EventTarget) {
    this.visible = !this.visible;
    this.ReadMore = !this.ReadMore;
  }

    createChart(){
      var xValues = ["GIS_Plot_S", "Vacant", "Allotted", "Encroachment", "Open Space"];
      var yValues = [55, 49, 44, 24, 15];
      var barColors = ["red", "green","blue","orange","brown"];
      this.chart = new Chart("MyChart",  {
        type: "bar",
        data: {
          labels: xValues,
          datasets: [{
            backgroundColor: barColors,
            data: yValues
          }]
        },
        options: {
          plugins: {
            legend: {
              display: false,
            }
          },
          aspectRatio:1.1
        }
      });
    }
}